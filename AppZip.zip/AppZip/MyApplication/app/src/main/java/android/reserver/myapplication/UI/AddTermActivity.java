package android.reserver.myapplication.UI;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.reserver.myapplication.Database.Repository;
import android.reserver.myapplication.Entity.Term;
import android.reserver.myapplication.R;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


public class AddTermActivity extends AppCompatActivity {
    private Repository repository;
    private EditText editTermStart;
    private EditText editTermEnd;
    private DatePickerDialog.OnDateSetListener startDate;
    private DatePickerDialog.OnDateSetListener endDate;
    private final Calendar myCalendarStart = Calendar.getInstance();
    private final Calendar myCalendarEnd = Calendar.getInstance();

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_term);

        // Instantiate the Repository class
        repository = new Repository(getApplication());

        // Initialize views
        editTermStart = findViewById(R.id.assessmentType);
        editTermEnd = findViewById(R.id.termEnd);

        // Set initial date values
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        editTermStart.setText(sdf.format(new Date()));
        editTermEnd.setText(sdf.format(new Date()));

        // Set click listeners for date pickers
        editTermStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDialog(startDate, myCalendarStart);
            }
        });

        editTermEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDialog(endDate, myCalendarEnd);
            }
        });

        // Initialize the save button click listener
        Button saveButton = findViewById(R.id.buttonSaveAssessment);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveTerm();
            }
        });

        // Initialize the date set listeners
        startDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                myCalendarStart.set(Calendar.YEAR, year);
                myCalendarStart.set(Calendar.MONTH, monthOfYear);
                myCalendarStart.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel(editTermStart, myCalendarStart);
            }
        };

        endDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                myCalendarEnd.set(Calendar.YEAR, year);
                myCalendarEnd.set(Calendar.MONTH, monthOfYear);
                myCalendarEnd.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel(editTermEnd, myCalendarEnd);
            }
        };
    }

    private void showDatePickerDialog(DatePickerDialog.OnDateSetListener dateSetListener, Calendar calendar) {
        new DatePickerDialog(
                AddTermActivity.this,
                dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    private void updateLabel(EditText editText, Calendar calendar) {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        editText.setText(sdf.format(calendar.getTime()));
    }

    private void saveTerm() {
        // Retrieve the entered information from EditText views
        EditText editTermName = findViewById(R.id.termName);
        String termName = editTermName.getText().toString();

        // Create a Term object with the entered information
        Term term = new Term(0, termName, editTermStart.getText().toString(), editTermEnd.getText().toString());

        // Insert the term into the database using Repository
        repository.insertTerm(term);

        // Return to the activity_terms_list.xml screen
        finish();
    }
}

