package android.reserver.myapplication.UI;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.reserver.myapplication.Database.Repository;
import android.reserver.myapplication.Entity.Course;
import android.reserver.myapplication.R;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class CourseList extends AppCompatActivity implements CourseAdapter.OnItemClickListener, CourseAdapter.OnDeleteClickListener {

    private CourseAdapter mCourseAdapter;
    private Repository mRepository;
    private List<Course> courses;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_list);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        setupNavigationBar();

        RecyclerView recyclerView = findViewById(R.id.recyclerViewCourses);
        mRepository = new Repository(getApplication()); // Initialize the mRepository object
        List<Course> courseList = mRepository.getmAllCourses(); // Fetch the course list from the repository
        mCourseAdapter = new CourseAdapter(this); // Pass the context and course list
        recyclerView.setAdapter(mCourseAdapter);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        FloatingActionButton fabAddCourse = findViewById(R.id.fabAddCourse);
        fabAddCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToAddCourse();
            }
        });

        mCourseAdapter.setOnItemClickListener(this);
        mCourseAdapter.setOnDeleteClickListener(this); // Set the delete click listener
    }

    private void setupNavigationBar() {
        BottomNavigationView navigationBar = findViewById(R.id.navigation_bar);
        navigationBar.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.home_fragment) {
                    goHome();
                    return true;
                } else if (itemId == R.id.terms_fragment) {
                    goToTermList();
                    return true;
                } else if (itemId == R.id.assessments_fragment) {
                    goToAssessmentList();
                    return true;
                }
                return true;
            }
        });

        // Enable all items and disable only "Terms" button
        Menu menu = navigationBar.getMenu();
        for (int i = 0; i < menu.size(); i++) {
            MenuItem item = menu.getItem(i);
            if (item.getItemId() == R.id.courses_fragment) {
                item.setChecked(true);
                item.setEnabled(false);
            } else {
                item.setEnabled(true);
            }
        }
    }



    private void goHome() {
        Intent intent = new Intent(CourseList.this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Add the flag
        startActivity(intent);
        finish(); // Finish the current activity
    }

    private void goToTermList() {
        Intent intent = new Intent(CourseList.this, TermList.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Add the flag
        startActivity(intent);
        finish(); // Finish the current activity
    }

    private void goToAssessmentList() {
        Intent intent = new Intent(CourseList.this, AssessmentList.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Add the flag
        startActivity(intent);
        finish(); // Finish the current activity
    }

    private void loadCourses() {
        courses = mRepository.getmAllCourses();
        if (courses.isEmpty()) {
            // Handle the case when there are no courses in the database
            // You can show a message or perform any other action
        } else {
            mCourseAdapter.setCourses(courses);
        }
    }

    @Override
    public void onItemClick(Course course) {
        Intent intent = new Intent(CourseList.this, CourseDetail.class);
        intent.putExtra("courseID", course.getCourseID()); // Pass the course ID
        startActivity(intent);
    }

    @Override
    public void onItemDeleteClick(Course course) {
        promptDeleteConfirmation(course); // Prompt delete confirmation
    }

    private void promptDeleteConfirmation(final Course course) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Confirm Delete")
                .setMessage("Are you sure you want to delete this course?")
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteCourse(course);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteCourse(Course course) {
        mRepository.deleteCourse(course);
        // Perform any other required actions after deleting the course
        loadCourses(); // Refresh the course list after deletion
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_courselist, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            case R.id.menu_toggle_delete:
                mCourseAdapter.toggleDeleteButtons();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void goToAddCourse() {
        Intent intent = new Intent(CourseList.this, AddCourseActivity.class);
        startActivity(intent);
    }
    @Override
    protected void onResume() {
        super.onResume();
        loadCourses();
    }


}
