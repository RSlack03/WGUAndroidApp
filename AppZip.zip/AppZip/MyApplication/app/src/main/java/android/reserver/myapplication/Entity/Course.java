package android.reserver.myapplication.Entity;

import android.reserver.myapplication.Entity.Term;
import android.reserver.myapplication.UI.DateConverter;

import androidx.annotation.Nullable;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

@Entity(tableName = "course", foreignKeys = {
        @ForeignKey(entity = Term.class, parentColumns = "termID", childColumns = "termID",
                onDelete = ForeignKey.SET_NULL)
})
@TypeConverters(DateConverter.class)
public class Course {
    @PrimaryKey(autoGenerate = true)
    private int courseID;

    private String courseName;
    private String courseStart;
    private String courseEnd;
    private String courseProgress;
    private String courseNote;
    private String professorName;
    private String professorEmail;
    private String professorPhone;

    @Nullable
    private Integer termID;

    public Course(int courseID, String courseName, String courseStart, String courseEnd,
                  String courseProgress, String courseNote, String professorName,
                  String professorEmail, String professorPhone, Integer termID) {
        this.courseID = courseID;
        this.courseName = courseName;
        this.courseStart = courseStart;
        this.courseEnd = courseEnd;
        this.courseProgress = courseProgress;
        this.courseNote = courseNote;
        this.professorName = professorName;
        this.professorEmail = professorEmail;
        this.professorPhone = professorPhone;
        this.termID = termID;
    }

    public int getCourseID() {
        return courseID;
    }

    public void setCourseID(int courseID) {
        this.courseID = courseID;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseStart() {
        return courseStart;
    }

    public void setCourseStart(String courseStart) {
        this.courseStart = courseStart;
    }

    public String getCourseEnd() {
        return courseEnd;
    }

    public void setCourseEnd(String courseEnd) {
        this.courseEnd = courseEnd;
    }

    public String getCourseProgress() {
        return courseProgress;
    }

    public void setCourseProgress(String courseProgress) {
        this.courseProgress = courseProgress;
    }

    public String getCourseNote() {
        return courseNote;
    }

    public void setCourseNote(String courseNote) {
        this.courseNote = courseNote;
    }

    public String getProfessorName() {
        return professorName;
    }

    public void setProfessorName(String professorName) {
        this.professorName = professorName;
    }

    public String getProfessorEmail() {
        return professorEmail;
    }

    public void setProfessorEmail(String professorEmail) {
        this.professorEmail = professorEmail;
    }

    public String getProfessorPhone() {
        return professorPhone;
    }

    public void setProfessorPhone(String professorPhone) {
        this.professorPhone = professorPhone;
    }

    @Nullable
    public Integer getTermID() {
        return termID;
    }

    public void setTermID(@Nullable Integer termID) {
        this.termID = termID;
    }

    @Override
    public String toString() {
        return "Course{" +
                "courseID=" + courseID +
                ", courseName='" + courseName + '\'' +
                ", courseStart='" + courseStart + '\'' +
                ", courseEnd='" + courseEnd + '\'' +
                ", courseProgress='" + courseProgress + '\'' +
                ", courseNote='" + courseNote + '\'' +
                ", professorName='" + professorName + '\'' +
                ", professorEmail='" + professorEmail + '\'' +
                ", professorPhone='" + professorPhone + '\'' +
                ", termID=" + termID +
                '}';
    }
}