package android.reserver.myapplication.UI;

import android.content.Context;
import android.reserver.myapplication.Entity.Course;
import android.reserver.myapplication.R;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CourseAdapter extends RecyclerView.Adapter<CourseAdapter.CourseViewHolder> {
    private List<Course> mCourses;
    private final Context mContext;
    private OnItemClickListener mListener;
    private OnDeleteClickListener mDeleteListener;
    private boolean mShowDeleteButtons;

    public interface OnItemClickListener {
        void onItemClick(Course course);
    }

    public interface OnDeleteClickListener {
        void onItemDeleteClick(Course course);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    public void setOnDeleteClickListener(OnDeleteClickListener listener) {
        mDeleteListener = listener;
    }

    public CourseAdapter(Context context) {
        mContext = context;
        mCourses = new ArrayList<>();
    }

    @NonNull
    @Override
    public CourseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.course_list_item, parent, false);
        return new CourseViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull CourseViewHolder holder, int position) {
        Course course = mCourses.get(position);
        holder.bindCourse(course);

        if (mShowDeleteButtons) {
            holder.deleteButton.setVisibility(View.VISIBLE);
        } else {
            holder.deleteButton.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return mCourses.size();
    }

    public void setCourses(List<Course> courses) {
        mCourses = courses;
        notifyDataSetChanged();
    }

    public void toggleDeleteButtons() {
        mShowDeleteButtons = !mShowDeleteButtons;
        notifyDataSetChanged();
    }

    public class CourseViewHolder extends RecyclerView.ViewHolder {
        private final TextView courseNameTextView;
        private final ImageButton deleteButton;

        public CourseViewHolder(View itemView) {
            super(itemView);
            courseNameTextView = itemView.findViewById(R.id.textViewCourseName);
            deleteButton = itemView.findViewById(R.id.buttonDelete);

            courseNameTextView.setOnClickListener(view -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    Course course = mCourses.get(position);
                    if (mListener != null) {
                        mListener.onItemClick(course);
                    }
                }
            });

            deleteButton.setOnClickListener(view -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    Course course = mCourses.get(position);
                    if (mDeleteListener != null) {
                        mDeleteListener.onItemDeleteClick(course);
                    }
                }
            });
        }

        public void bindCourse(Course course) {
            courseNameTextView.setText(course.getCourseName());
        }
    }
}
