package android.reserver.myapplication.UI;

import android.content.Context;
import android.content.Intent;
import android.reserver.myapplication.Entity.Term;
import android.reserver.myapplication.R;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TermAdapter extends RecyclerView.Adapter<TermAdapter.TermViewHolder> {

    private List<Term> mTerms;
    private final Context mContext;
    private OnItemClickListener mListener;
    private OnDeleteClickListener mDeleteListener;
    private boolean mShowDeleteButtons;

    public interface OnItemClickListener {
        void onItemClick(Term term);
    }

    public interface OnDeleteClickListener {
        void onItemDeleteClick(Term term);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    public void setOnDeleteClickListener(OnDeleteClickListener listener) {
        mDeleteListener = listener;
    }

    public TermAdapter(Context context) {
        mContext = context;
    }

    @NonNull
    @Override
    public TermViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.term_list_item, parent, false);
        return new TermViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull TermViewHolder holder, int position) {
        if (mTerms != null && position < mTerms.size()) {
            Term term = mTerms.get(position);
            holder.bindTerm(term);
        } else {
            holder.termNameTextView.setText("No Terms Added");
        }

        if (mShowDeleteButtons) {
            holder.deleteButton.setVisibility(View.VISIBLE);
        } else {
            holder.deleteButton.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return mTerms != null ? mTerms.size() : 0;
    }

    public void setTerms(List<Term> terms) {
        mTerms = terms;
        notifyDataSetChanged();
    }

    public void toggleDeleteButtons() {
        mShowDeleteButtons = !mShowDeleteButtons;
        notifyDataSetChanged();
    }

    class TermViewHolder extends RecyclerView.ViewHolder {
        private final TextView termNameTextView;
        private final ImageButton deleteButton;

        private TermViewHolder(View itemView) {
            super(itemView);
            termNameTextView = itemView.findViewById(R.id.textViewTermName);
            deleteButton = itemView.findViewById(R.id.buttonDelete);

            itemView.setOnClickListener(view -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    Term term = mTerms.get(position);
                    if (mListener != null) {
                        mListener.onItemClick(term);
                    }
                }
            });

            deleteButton.setOnClickListener(view -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    Term term = mTerms.get(position);
                    if (mDeleteListener != null) {
                        mDeleteListener.onItemDeleteClick(term);
                    }
                }
            });
        }

        public void bindTerm(Term term) {
            termNameTextView.setText(term.getTermName());
        }
    }
}

