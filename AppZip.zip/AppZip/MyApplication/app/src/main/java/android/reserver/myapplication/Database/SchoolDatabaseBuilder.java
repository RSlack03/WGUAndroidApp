package android.reserver.myapplication.Database;


import android.content.Context;
import android.reserver.myapplication.DAO.AssessmentDAO;
import android.reserver.myapplication.DAO.CourseDAO;
import android.reserver.myapplication.DAO.TermDAO;
import android.reserver.myapplication.Entity.Assessment;
import android.reserver.myapplication.Entity.Course;
import android.reserver.myapplication.Entity.Term;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;


@Database(entities={Assessment.class, Course.class, Term.class}, version=9, exportSchema = false)
public abstract class SchoolDatabaseBuilder extends RoomDatabase {
    public abstract AssessmentDAO assessmentDAO();
    public abstract CourseDAO courseDAO();
    public abstract TermDAO termDAO();

    private static volatile SchoolDatabaseBuilder INSTANCE;

    static SchoolDatabaseBuilder getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (SchoolDatabaseBuilder.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(), SchoolDatabaseBuilder.class, "myTermsDatabase.db")
                            .allowMainThreadQueries()
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
        }
    }