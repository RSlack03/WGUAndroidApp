package android.reserver.myapplication.UI;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.reserver.myapplication.Database.Repository;
import android.reserver.myapplication.Entity.Assessment;
import android.reserver.myapplication.Entity.Course;
import android.reserver.myapplication.R;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AddAssessmentActivity extends AppCompatActivity {

    private EditText editTextAssessmentName;
    private Spinner spinnerAssessmentType;
    private EditText editTextAssessmentStart;
    private EditText editTextAssessmentEnd;
    private Spinner spinnerCourseID;

    private Repository mRepository;
    private List<Course> mCourses;

    private final Calendar myCalendarStart = Calendar.getInstance();
    private final Calendar myCalendarEnd = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_assessment);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mRepository = new Repository(getApplication());

        editTextAssessmentName = findViewById(R.id.editTextAssessmentName);
        spinnerAssessmentType = findViewById(R.id.assessmentType);
        editTextAssessmentStart = findViewById(R.id.assessmentStart);
        editTextAssessmentEnd = findViewById(R.id.assessmentEnd);
        spinnerCourseID = findViewById(R.id.spinnerCourseID);

        // Populate spinnerAssessmentType with assessment types
        ArrayAdapter<CharSequence> assessmentTypeAdapter = ArrayAdapter.createFromResource(
                this,
                R.array.assessmentType,
                android.R.layout.simple_spinner_item
        );
        assessmentTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerAssessmentType.setAdapter(assessmentTypeAdapter);

        // Populate spinnerCourseID with course names
        mCourses = mRepository.getmAllCourses();
        List<String> courseNames = getCourseNames(mCourses);
        ArrayAdapter<String> courseAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, courseNames);
        courseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCourseID.setAdapter(courseAdapter);

        Button saveButton = findViewById(R.id.buttonSaveAssessment);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveAssessment();
            }
        });

        // Set onClickListener for start and end date pickers
        editTextAssessmentStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDialog(editTextAssessmentStart, myCalendarStart);
            }
        });

        editTextAssessmentEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDialog(editTextAssessmentEnd, myCalendarEnd);
            }
        });
    }

    private void showDatePickerDialog(final EditText editText, final Calendar calendar) {
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, monthOfYear);
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel(editText, calendar);
            }
        };

        new DatePickerDialog(
                AddAssessmentActivity.this,
                dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    private void updateLabel(EditText editText, Calendar calendar) {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        editText.setText(sdf.format(calendar.getTime()));
    }

    private List<String> getCourseNames(List<Course> courses) {
        List<String> courseNames = new ArrayList<>();
        courseNames.add("Not Yet Assigned"); // Add the "Not Yet Assigned" option
        for (Course course : courses) {
            courseNames.add(course.getCourseName());
        }
        return courseNames;
    }

    private void saveAssessment() {
        String assessmentName = editTextAssessmentName.getText().toString();
        String assessmentType = spinnerAssessmentType.getSelectedItem().toString();
        String assessmentStart = editTextAssessmentStart.getText().toString();
        String assessmentEnd = editTextAssessmentEnd.getText().toString();
        String selectedCourseName = spinnerCourseID.getSelectedItem().toString();
        int courseID = 0;

        if (!selectedCourseName.equals("Not Yet Assigned")) {
            // Find the selected course object based on the course name
            for (Course course : mCourses) {
                if (course.getCourseName().equals(selectedCourseName)) {
                    courseID = course.getCourseID();
                    break;
                }
            }
        }

        Assessment assessment = new Assessment(0, assessmentName, assessmentType, assessmentStart, assessmentEnd, courseID);
        mRepository.insertAssessment(assessment);
        finish();

        // Update the assessment list in AssessmentList activity
        //updateAssessmentList();
    }

    private void updateAssessmentList() {
        startActivity(new Intent(AddAssessmentActivity.this, AssessmentList.class));
    }
}
