package android.reserver.myapplication.UI;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.reserver.myapplication.Database.Repository;
import android.reserver.myapplication.Entity.Assessment;
import android.reserver.myapplication.R;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.List;

public class AssessmentList extends AppCompatActivity implements AssessmentAdapter.OnItemClickListener, AssessmentAdapter.OnDeleteClickListener {

    private AssessmentAdapter mAssessmentAdapter;
    private Repository mRepository;
    private List<Assessment> assessments;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assessment_list);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        setupNavigationBar();

        recyclerView = findViewById(R.id.recyclerViewAssessments);
        mRepository = new Repository(getApplication());
        List<Assessment> assessmentList = mRepository.getmAllAssessments();
        mAssessmentAdapter = new AssessmentAdapter(this);
        recyclerView.setAdapter(mAssessmentAdapter);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        FloatingActionButton fabAddAssessment = findViewById(R.id.fabAddAssessment);
        fabAddAssessment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToAddAssessment();
            }
        });

        mAssessmentAdapter.setOnItemClickListener(this);
        mAssessmentAdapter.setOnDeleteClickListener(this);
    }

    private void setupNavigationBar() {
        BottomNavigationView navigationBar = findViewById(R.id.navigation_bar);
        navigationBar.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.home_fragment) {
                    goHome();
                    return true;
                } else if (itemId == R.id.terms_fragment) {
                    goToTermList();
                    return true;
                } else if (itemId == R.id.courses_fragment) {
                    goToCourseList();
                    return true;
                }
                return true;
            }
        });

        // Enable all items and disable only "Terms" button
        Menu menu = navigationBar.getMenu();
        for (int i = 0; i < menu.size(); i++) {
            MenuItem item = menu.getItem(i);
            if (item.getItemId() == R.id.assessments_fragment) {
                item.setChecked(true);
                item.setEnabled(false);
            } else {
                item.setEnabled(true);
            }
        }
    }



    private void goHome() {
        Intent intent = new Intent(AssessmentList.this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Add the flag
        startActivity(intent);
        finish(); // Finish the current activity
    }

    private void goToTermList() {
        Intent intent = new Intent(AssessmentList.this, TermList.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Add the flag
        startActivity(intent);
        finish(); // Finish the current activity
    }

    private void goToCourseList() {
        Intent intent = new Intent(AssessmentList.this, CourseList.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Add the flag
        startActivity(intent);
        finish(); // Finish the current activity
    }

    private void goToAddAssessment() {
        Intent intent = new Intent(AssessmentList.this, AddAssessmentActivity.class);
        startActivity(intent);
    }

    private void loadAssessments() {
        assessments = mRepository.getmAllAssessments();
        if (assessments.isEmpty()) {
            // Handle the case when there are no assessments in the database
            // You can show a message or perform any other action
        } else {
            mAssessmentAdapter.setAssessments(assessments);
        }
    }

    @Override
    public void onItemClick(Assessment assessment) {
        Intent intent = new Intent(AssessmentList.this, AssessmentDetail.class);
        intent.putExtra("assessmentID", assessment.getAssessmentID());
        startActivity(intent);
    }

    @Override
    public void onItemDeleteClick(Assessment assessment) {
        promptDeleteConfirmation(assessment);
    }

    private void promptDeleteConfirmation(final Assessment assessment) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Confirm Delete")
                .setMessage("Are you sure you want to delete this assessment?")
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteAssessment(assessment);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteAssessment(Assessment assessment) {
        mRepository.deleteAssessment(assessment);
        loadAssessments();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_assessmentlist, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            case R.id.menu_toggle_delete:
                mAssessmentAdapter.toggleDeleteButtons();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadAssessments();
    }
}
