package android.reserver.myapplication.UI;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.reserver.myapplication.Database.Repository;
import android.reserver.myapplication.Entity.Assessment;
import android.reserver.myapplication.Entity.Course;
import android.reserver.myapplication.R;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AssessmentDetail extends AppCompatActivity {

    private EditText editTextAssessmentName;
    private Spinner spinnerAssessmentType;
    private EditText editTextAssessmentStart;
    private EditText editTextAssessmentEnd;
    private Spinner spinnerCourseID;
    private Button buttonSaveAssessment;

    private Repository mRepository;
    private List<Course> mCourses;
    private Assessment mAssessment;
    private DatePickerDialog.OnDateSetListener startDate;
    private DatePickerDialog.OnDateSetListener endDate;
    private final Calendar myCalendarStart = Calendar.getInstance();
    private final Calendar myCalendarEnd = Calendar.getInstance();

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assessment_detail);

        // Retrieve references to the views in the layout
        editTextAssessmentName = findViewById(R.id.editTextAssessmentName);
        spinnerAssessmentType = findViewById(R.id.assessmentType);
        editTextAssessmentStart = findViewById(R.id.editAssessmentStart);
        editTextAssessmentEnd = findViewById(R.id.editAssessmentEnd);
        spinnerCourseID = findViewById(R.id.spinnerCourseID);
        buttonSaveAssessment = findViewById(R.id.buttonSaveAssessment);

        // Initialize the repository and fetch necessary data
        mRepository = new Repository(getApplication());
        mCourses = mRepository.getmAllCourses();

        // Get the assessment ID passed through the intent extras
        int assessmentID = getIntent().getIntExtra("assessmentID", -1);
        if (assessmentID != -1) {
            // Fetch the assessment object from the repository using the ID
            mAssessment = mRepository.getAssessmentByID(assessmentID);
            if (mAssessment != null) {
                // Populate the views with the assessment data
                editTextAssessmentName.setText(mAssessment.getAssessmentName());
                editTextAssessmentStart.setText(mAssessment.getAssessmentStart());
                editTextAssessmentEnd.setText(mAssessment.getAssessmentEnd());

                // Set up the spinner for assessment type
                ArrayAdapter<CharSequence> assessmentTypeAdapter = ArrayAdapter.createFromResource(
                        this,
                        R.array.assessmentType,
                        android.R.layout.simple_spinner_item
                );
                assessmentTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerAssessmentType.setAdapter(assessmentTypeAdapter);
                int assessmentTypePosition = assessmentTypeAdapter.getPosition(mAssessment.getAssessmentType());
                spinnerAssessmentType.setSelection(assessmentTypePosition);

                // Set up the spinner for course names
                List<String> courseNames = getCourseNames(mCourses);
                ArrayAdapter<String> courseAdapter = new ArrayAdapter<>(this,
                        android.R.layout.simple_spinner_item, courseNames);
                courseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerCourseID.setAdapter(courseAdapter);

                // Find the index of the saved course name in the courseNames list
                int courseIndex = getCourseIndex(mAssessment.getCourseID());
                if (courseIndex != -1) {
                    // Set the selected item to the saved course name
                    spinnerCourseID.setSelection(courseIndex);
                } else {
                    // Set the selected item to "None Assigned" if the course name is not found
                    spinnerCourseID.setSelection(0);
                }
            }
        }

        // Set click listeners for date pickers
        editTextAssessmentStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDialog(startDate, myCalendarStart);
            }
        });

        editTextAssessmentEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDialog(endDate, myCalendarEnd);
            }
        });

        // Initialize the date set listeners
        startDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                myCalendarStart.set(Calendar.YEAR, year);
                myCalendarStart.set(Calendar.MONTH, monthOfYear);
                myCalendarStart.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel(editTextAssessmentStart, myCalendarStart);
            }
        };

        endDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                myCalendarEnd.set(Calendar.YEAR, year);
                myCalendarEnd.set(Calendar.MONTH, monthOfYear);
                myCalendarEnd.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel(editTextAssessmentEnd, myCalendarEnd);
            }
        };

        // Set up the click listener for the save button
        buttonSaveAssessment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateAssessment();
            }
        });
    }

    private void showDatePickerDialog(DatePickerDialog.OnDateSetListener dateSetListener, Calendar calendar) {
        new DatePickerDialog(
                AssessmentDetail.this,
                dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    private void updateLabel(EditText editText, Calendar calendar) {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        editText.setText(sdf.format(calendar.getTime()));
    }

    private List<String> getCourseNames(List<Course> courses) {
        List<String> courseNames = new ArrayList<>();
        courseNames.add("None Assigned"); // Add the "None Assigned" option
        for (Course course : courses) {
            courseNames.add(course.getCourseName());
        }
        return courseNames;
    }

    private int getCourseIndex(int courseID) {
        for (int i = 0; i < mCourses.size(); i++) {
            if (mCourses.get(i).getCourseID() == courseID) {
                return i + 1; // Add 1 to account for the "None Assigned" option
            }
        }
        return 0; // Return 0 to select "None Assigned" if the course ID is not found
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_assessment_detail, menu);

        return true;
    }



    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
            case R.id.notifystart:
                String dateFromScreen = editTextAssessmentStart.getText().toString();
                String myFormat = "MM/dd/yy";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
                Date myDate = null;
                try {
                    myDate = sdf.parse(dateFromScreen);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                if (myDate != null) {
                    long trigger = myDate.getTime();
                    Intent startIntent = new Intent(AssessmentDetail.this, MyReceiver.class);
                    startIntent.putExtra("key", dateFromScreen + " this should trigger");
                    PendingIntent startSender = PendingIntent.getBroadcast(
                            AssessmentDetail.this,
                            ++MainActivity.numAlert,
                            startIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                    );                    AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                    alarmManager.set(AlarmManager.RTC_WAKEUP, trigger, startSender);
                    Toast.makeText(AssessmentDetail.this, "Assessment Start Alert successfully set for: "+ dateFromScreen, Toast.LENGTH_SHORT).show();

                }
                return true;

            case R.id.notifyend:
                String endDateFromScreen = editTextAssessmentEnd.getText().toString();
                String endMyFormat = "MM/dd/yy";
                SimpleDateFormat endSdf = new SimpleDateFormat(endMyFormat, Locale.US);
                Date endMyDate = null;
                try {
                    endMyDate = endSdf.parse(endDateFromScreen);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                if (endMyDate != null) {
                    long endTrigger = endMyDate.getTime();
                    Intent endIntent = new Intent(AssessmentDetail.this, MyReceiver.class);
                    endIntent.putExtra("key", endDateFromScreen + " this should trigger for end");
                    PendingIntent endSender = PendingIntent.getBroadcast(
                            AssessmentDetail.this,
                            ++MainActivity.numAlert,
                            endIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                    );                    AlarmManager endAlarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                    endAlarmManager.set(AlarmManager.RTC_WAKEUP, endTrigger, endSender);
                    Toast.makeText(AssessmentDetail.this, "Assessment End Alert successfully set for: "+ endDateFromScreen, Toast.LENGTH_SHORT).show();

                }
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private void updateAssessment() {
        if (mAssessment != null) {
            // Retrieve the updated assessment data from the views
            String assessmentName = editTextAssessmentName.getText().toString();
            String assessmentType = spinnerAssessmentType.getSelectedItem().toString();
            String assessmentStart = editTextAssessmentStart.getText().toString();
            String assessmentEnd = editTextAssessmentEnd.getText().toString();
            String selectedCourseName = spinnerCourseID.getSelectedItem().toString();

            // Find the selected course object based on the course name
            Course selectedCourse = null;
            if (!selectedCourseName.equals("None Assigned")) {
                for (Course course : mCourses) {
                    if (course.getCourseName().equals(selectedCourseName)) {
                        selectedCourse = course;
                        break;
                    }
                }
            }

            // If the selected course is found, update the assessment
            if (selectedCourse != null || selectedCourseName.equals("None Assigned")) {
                int courseID = selectedCourse != null ? selectedCourse.getCourseID() : 0;

                // Update the assessment object
                mAssessment.setAssessmentName(assessmentName);
                mAssessment.setAssessmentType(assessmentType);
                mAssessment.setAssessmentStart(assessmentStart);
                mAssessment.setAssessmentEnd(assessmentEnd);
                mAssessment.setCourseID(courseID);

                // Update the assessment in the database
                mRepository.updateAssessment(mAssessment);

                // Show a toast message indicating the assessment has been updated
                Toast.makeText(AssessmentDetail.this, "Assessment updated", Toast.LENGTH_SHORT).show();

                // Return to the AssessmentList activity
                finish();
            } else {
                // Handle the case when the selected course is not found
                Toast.makeText(AssessmentDetail.this, "Invalid course selected", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
