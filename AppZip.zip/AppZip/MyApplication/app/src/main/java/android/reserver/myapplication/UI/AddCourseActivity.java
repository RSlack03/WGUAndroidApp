package android.reserver.myapplication.UI;

import android.app.DatePickerDialog;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.reserver.myapplication.Database.Repository;
import android.reserver.myapplication.Entity.Course;
import android.reserver.myapplication.Entity.Term;
import android.reserver.myapplication.R;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AddCourseActivity extends AppCompatActivity {

    private EditText editTextCourseName;
    private EditText editTextCourseStart;
    private EditText editTextCourseEnd;
    private Spinner spinnerCourseProgress;
    private EditText editTextCourseNote;
    private EditText editTextProfessorName;
    private EditText editTextProfessorEmail;
    private EditText editTextProfessorPhone;
    private Spinner spinnerTermID;

    private Repository mRepository;

    private final Calendar myCalendarStart = Calendar.getInstance();
    private final Calendar myCalendarEnd = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_course);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mRepository = new Repository(getApplication());

        editTextCourseName = findViewById(R.id.editTextAssessmentName);
        editTextCourseStart = findViewById(R.id.courseStart);
        editTextCourseEnd = findViewById(R.id.assessmentStart);
        spinnerCourseProgress = findViewById(R.id.assessmentEnd);
        editTextCourseNote = findViewById(R.id.courseNote);
        editTextProfessorName = findViewById(R.id.professorName);
        editTextProfessorEmail = findViewById(R.id.professorEmail);
        editTextProfessorPhone = findViewById(R.id.professorPhone);
        spinnerTermID = findViewById(R.id.termID);

        ArrayAdapter<CharSequence> progressAdapter = ArrayAdapter.createFromResource(
                this,
                R.array.course_progress_options,
                android.R.layout.simple_spinner_item
        );
        progressAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCourseProgress.setAdapter(progressAdapter);

        List<Term> termList = mRepository.getmAllTerms();
        ArrayAdapter<String> termAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                getTermNames(termList)
        );
        termAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTermID.setAdapter(termAdapter);

        Button saveButton = findViewById(R.id.buttonSaveAssessment);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCourse();
            }
        });

        editTextCourseStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDialog(editTextCourseStart, myCalendarStart);
            }
        });

        editTextCourseEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDialog(editTextCourseEnd, myCalendarEnd);
            }
        });
    }

    private void showDatePickerDialog(final EditText editText, final Calendar calendar) {
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, monthOfYear);
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel(editText, calendar);
            }
        };

        new DatePickerDialog(
                AddCourseActivity.this,
                dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    private void updateLabel(EditText editText, Calendar calendar) {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        editText.setText(sdf.format(calendar.getTime()));
    }

    private List<String> getTermNames(List<Term> termList) {
        List<String> termNames = new ArrayList<>();
        for (Term term : termList) {
            termNames.add(term.getTermName());
        }
        return termNames;
    }

    private void saveCourse() {
        String courseName = editTextCourseName.getText().toString();
        String courseStart = editTextCourseStart.getText().toString();
        String courseEnd = editTextCourseEnd.getText().toString();
        String courseProgress = spinnerCourseProgress.getSelectedItem().toString();
        String courseNote = editTextCourseNote.getText().toString();
        String professorName = editTextProfessorName.getText().toString();
        String professorEmail = editTextProfessorEmail.getText().toString();
        String professorPhone = editTextProfessorPhone.getText().toString();
        String selectedTermName = spinnerTermID.getSelectedItem().toString();

        Term selectedTerm = null;
        List<Term> termList = mRepository.getmAllTerms();
        for (Term term : termList) {
            if (term.getTermName().equals(selectedTermName)) {
                selectedTerm = term;
                break;
            }
        }

        if (selectedTerm != null) {
            int termID = selectedTerm.getTermID();
            Course course = new Course(0, courseName, courseStart, courseEnd, courseProgress,
                    courseNote, professorName, professorEmail, professorPhone, termID);
            mRepository.insertCourse(course);
            finish();
        }
    }
}
