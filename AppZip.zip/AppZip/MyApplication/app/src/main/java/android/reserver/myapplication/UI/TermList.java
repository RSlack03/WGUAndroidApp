package android.reserver.myapplication.UI;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.reserver.myapplication.Database.Repository;
import android.reserver.myapplication.Entity.Course;
import android.reserver.myapplication.Entity.Term;
import android.reserver.myapplication.R;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class TermList extends AppCompatActivity implements TermAdapter.OnItemClickListener, TermAdapter.OnDeleteClickListener {

    private TermAdapter mTermAdapter;
    private Repository mRepository;
    private List<Term> terms;

    @Override
    public void onItemDeleteClick(Term term) {
        promptDeleteConfirmation(term); // Prompt delete confirmation
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms_list);
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setupNavigationBar();

        RecyclerView recyclerView = findViewById(R.id.recyclerViewTerms);
        mTermAdapter = new TermAdapter(this);
        recyclerView.setAdapter(mTermAdapter);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        mRepository = new Repository(getApplication());

        FloatingActionButton addTermBtn = findViewById(R.id.fabAddTerm);
        addTermBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToAddTerm();
            }
        });

        mTermAdapter.setOnItemClickListener(this);
        mTermAdapter.setOnDeleteClickListener(this); // Set the delete click listener

    }

    private void setupNavigationBar() {
        BottomNavigationView navigationBar = findViewById(R.id.navigation_bar);
        navigationBar.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.home_fragment) {
                    goHome();
                    return true;
                } else if (itemId == R.id.courses_fragment) {
                    goToCourseList();
                    return true;
                } else if (itemId == R.id.assessments_fragment) {
                    goToAssessmentList();
                    return true;
                }
                return true;
            }
        });

        // Enable all items and disable only "Terms" button
        Menu menu = navigationBar.getMenu();
        for (int i = 0; i < menu.size(); i++) {
            MenuItem item = menu.getItem(i);
            if (item.getItemId() == R.id.terms_fragment) {
                item.setChecked(true);
                item.setEnabled(false);
            } else {
                item.setEnabled(true);
            }
        }
    }



    private void goHome() {
        Intent intent = new Intent(TermList.this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Add the flag
        startActivity(intent);
        finish(); // Finish the current activity
    }

    private void goToCourseList() {
        Intent intent = new Intent(TermList.this, CourseList.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Add the flag
        startActivity(intent);
        finish(); // Finish the current activity
    }

    private void goToAssessmentList() {
        Intent intent = new Intent(TermList.this, AssessmentList.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Add the flag
        startActivity(intent);
        finish(); // Finish the current activity
    }


    private void loadTerms() {
        terms = mRepository.getmAllTerms();
        if (terms.isEmpty()) {
            // Handle the case when there are no terms in the database
            // You can show a message or perform any other action
        } else {
            mTermAdapter.setTerms(terms);
        }
    }

    public void goToAddTerm() {
        Intent intent = new Intent(TermList.this, AddTermActivity.class);
        startActivity(intent);
    }

    @Override
    public void onItemClick(Term term) {
        Intent intent = new Intent(TermList.this, TermDetail.class);
        intent.putExtra("termID", term.getTermID());
        intent.putExtra("termName", term.getTermName());
        intent.putExtra("startDate", term.getTermStart());
        intent.putExtra("endDate", term.getTermEnd());
        startActivity(intent);
    }

    private void promptDeleteConfirmation(final Term term) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Confirm Delete")
                .setMessage("Are you sure you want to delete this term?")
                .setPositiveButton("Delete", (dialog, which) -> deleteTerm(term))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteTerm(Term term) {
        int termID = term.getTermID();
        List<Course> courses = mRepository.getCoursesByTermID(termID);

        if (!courses.isEmpty()) {
            new MaterialAlertDialogBuilder(this)
                    .setTitle("Unable to Delete")
                    .setMessage("This term cannot be deleted because it has courses assigned to it. Remove the associated courses before deleting the term.")
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }
        mRepository.deleteTerm(term);
        loadTerms(); // Refresh the term list
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_termlist, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.menu_toggle_delete) {
            mTermAdapter.toggleDeleteButtons();
            return true;
        } else if (itemId == android.R.id.home) {
            finish(); // Handle the Up button action (back navigation)
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadTerms();
    }
}

