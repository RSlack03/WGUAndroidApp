package android.reserver.myapplication.UI;

import android.content.Context;
import android.content.Intent;
import android.reserver.myapplication.Entity.Assessment;
import android.reserver.myapplication.R;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AssessmentAdapter extends RecyclerView.Adapter<AssessmentAdapter.AssessmentViewHolder> {
    private List<Assessment> mAssessments;
    private final Context mContext;
    private OnItemClickListener mListener;
    private OnDeleteClickListener mDeleteListener;
    private boolean mShowDeleteButtons;

    public interface OnItemClickListener {
        void onItemClick(Assessment assessment);
    }

    public interface OnDeleteClickListener {
        void onItemDeleteClick(Assessment assessment);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    public void setOnDeleteClickListener(OnDeleteClickListener listener) {
        mDeleteListener = listener;
    }

    public AssessmentAdapter(Context context) {
        mContext = context;
    }

    public void setAssessments(List<Assessment> assessments) {
        mAssessments = assessments;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public AssessmentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.assessment_list_item, parent, false);
        return new AssessmentViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull AssessmentViewHolder holder, int position) {
        if (mAssessments == null || mAssessments.isEmpty()) {
            return;
        }

        Assessment assessment = mAssessments.get(position);
        holder.bindAssessment(assessment);

        if (mShowDeleteButtons) {
            holder.deleteButton.setVisibility(View.VISIBLE);
        } else {
            holder.deleteButton.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return mAssessments != null ? mAssessments.size() : 0;
    }

    public void toggleDeleteButtons() {
        mShowDeleteButtons = !mShowDeleteButtons;
        notifyDataSetChanged();
    }

    public class AssessmentViewHolder extends RecyclerView.ViewHolder {
        private final TextView assessmentNameTextView;
        private final ImageButton deleteButton;

        public AssessmentViewHolder(View itemView) {
            super(itemView);
            assessmentNameTextView = itemView.findViewById(R.id.textViewAssessmentName);
            deleteButton = itemView.findViewById(R.id.buttonDelete);

            itemView.setOnClickListener(view -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    Assessment assessment = mAssessments.get(position);
                    if (mListener != null) {
                        mListener.onItemClick(assessment);
                    }
                }
            });

            deleteButton.setOnClickListener(view -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    Assessment assessment = mAssessments.get(position);
                    if (mDeleteListener != null) {
                        mDeleteListener.onItemDeleteClick(assessment);
                    }
                }
            });
        }

        public void bindAssessment(Assessment assessment) {
            assessmentNameTextView.setText(assessment.getAssessmentName());
            // Bind other assessment data to respective views
            // ...
        }
    }
}
