package android.reserver.myapplication.DAO;

import android.reserver.myapplication.Entity.Term;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface TermDAO {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Term term);

    @Update
    void update(Term term);

    @Delete
    void delete(Term term);

    @Query("SELECT * FROM term ORDER BY termID ASC")
    List<Term> getAllTerms();

    @Query("SELECT * FROM term WHERE termID = :termID")
    Term getTermByID(int termID);

    @Query("SELECT termID FROM term WHERE termName = :termName")
    int getTermIDByName(String termName);

}
