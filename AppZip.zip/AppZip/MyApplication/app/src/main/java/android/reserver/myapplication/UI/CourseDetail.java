package android.reserver.myapplication.UI;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.ParseException;
import android.os.Bundle;
import android.reserver.myapplication.Database.Repository;
import android.reserver.myapplication.Entity.Assessment;
import android.reserver.myapplication.Entity.Course;
import android.reserver.myapplication.Entity.Term;
import android.reserver.myapplication.R;
import android.reserver.myapplication.UI.AssessmentAdapter;
import android.reserver.myapplication.UI.CourseList;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CourseDetail extends AppCompatActivity implements AssessmentAdapter.OnItemClickListener {

    private EditText courseNameEditText;
    private EditText courseStartEditText;
    private EditText courseEndEditText;
    private Spinner courseProgressSpinner;
    private EditText courseNoteEditText;
    private EditText professorNameEditText;
    private EditText professorEmailEditText;
    private EditText professorPhoneEditText;
    private Spinner termIDSpinner;
    private Button saveChangesButton;
    private Button addAssessmentButton;
    private RecyclerView recyclerViewAssessments;
    private AssessmentAdapter assessmentAdapter;
    private int courseID;

    private Repository mRepository;
    private Course course;
    private DatePickerDialog.OnDateSetListener startDate;
    private DatePickerDialog.OnDateSetListener endDate;
    private final Calendar myCalendarStart = Calendar.getInstance();
    private final Calendar myCalendarEnd = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_detail);

        // Initialize the repository
        mRepository = new Repository(getApplication());

        courseNameEditText = findViewById(R.id.editCourseName);
        courseStartEditText = findViewById(R.id.editCourseStart);
        courseEndEditText = findViewById(R.id.editCourseEnd);
        courseProgressSpinner = findViewById(R.id.editCourseProgress);
        courseNoteEditText = findViewById(R.id.editCourseNote);
        professorNameEditText = findViewById(R.id.editProfessorName);
        professorEmailEditText = findViewById(R.id.editProfessorEmail);
        professorPhoneEditText = findViewById(R.id.editProfessorPhone);
        termIDSpinner = findViewById(R.id.editTermID);
        saveChangesButton = findViewById(R.id.buttonSaveChanges);
        addAssessmentButton = findViewById(R.id.buttonAddAssessment);
        recyclerViewAssessments = findViewById(R.id.recyclerViewAssessments);

        // Get the course ID from the intent
        courseID = getIntent().getIntExtra("courseID", -1);
        if (courseID != -1) {
            // Fetch the course details using the course ID from the repository or database
            course = mRepository.getCourseByID(courseID);
            if (course != null) {
                // Set the course details in the respective EditText fields
                courseNameEditText.setText(course.getCourseName());
                courseStartEditText.setText(course.getCourseStart());
                courseEndEditText.setText(course.getCourseEnd());
                courseNoteEditText.setText(course.getCourseNote());
                professorNameEditText.setText(course.getProfessorName());
                professorEmailEditText.setText(course.getProfessorEmail());
                professorPhoneEditText.setText(course.getProfessorPhone());
            }
        }

        // Set up the spinner for course progress
        ArrayAdapter<CharSequence> progressAdapter = ArrayAdapter.createFromResource(
                this,
                R.array.course_progress_options,
                android.R.layout.simple_spinner_item
        );
        progressAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        courseProgressSpinner.setAdapter(progressAdapter);
        if (course != null) {
            int progressPosition = progressAdapter.getPosition(course.getCourseProgress());
            courseProgressSpinner.setSelection(progressPosition);
        }

        // Set up the spinner for term selection
        List<Term> termList = mRepository.getmAllTerms();
        List<String> termNames = getTermNames(termList);
        ArrayAdapter<String> termAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, termNames);
        termAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        termIDSpinner.setAdapter(termAdapter);
        if (course != null) {
            int termPosition = getTermPosition(course.getTermID(), termList);
            termIDSpinner.setSelection(termPosition);
        }

        // Set up the RecyclerView for assessments
        recyclerViewAssessments.setLayoutManager(new LinearLayoutManager(this));
        assessmentAdapter = new AssessmentAdapter(this);
        recyclerViewAssessments.setAdapter(assessmentAdapter);

        // Fetch the assessments associated with the course from the repository or database
        List<Assessment> assessments = mRepository.getAssessmentsByCourseID(courseID);
        assessmentAdapter.setAssessments(assessments);

        // Set click listeners
        saveChangesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveChanges();
            }
        });

        // Set click listeners
        addAssessmentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToAddAssessment();
            }
        });

        assessmentAdapter.setOnItemClickListener(this);
        assessmentAdapter.setOnDeleteClickListener(new AssessmentAdapter.OnDeleteClickListener() {
            @Override
            public void onItemDeleteClick(Assessment assessment) {
                // Handle assessment delete click
            }
        });

        // Set initial date values
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        if (course != null) {
            courseStartEditText.setText(course.getCourseStart());
            courseEndEditText.setText(course.getCourseEnd());
        }

        // Set click listeners for date pickers
        courseStartEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDialog(startDate, myCalendarStart);
            }
        });

        courseEndEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDialog(endDate, myCalendarEnd);
            }
        });

        // Initialize the date set listeners
        startDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                myCalendarStart.set(Calendar.YEAR, year);
                myCalendarStart.set(Calendar.MONTH, monthOfYear);
                myCalendarStart.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel(courseStartEditText, myCalendarStart);
            }
        };

        endDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                myCalendarEnd.set(Calendar.YEAR, year);
                myCalendarEnd.set(Calendar.MONTH, monthOfYear);
                myCalendarEnd.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel(courseEndEditText, myCalendarEnd);
            }
        };
    }


    private void showDatePickerDialog(DatePickerDialog.OnDateSetListener dateSetListener, Calendar calendar) {
        new DatePickerDialog(
                CourseDetail.this,
                dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    private void updateLabel(EditText editText, Calendar calendar) {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        editText.setText(sdf.format(calendar.getTime()));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_course_detail, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.action_share) {
            shareCourseDetails();
            return true;
        } else if (itemId == R.id.notifystart) {
            setAlertForStartDate();
            return true;
        } else if (itemId == R.id.notifyend) {
            setAlertForEndDate();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private void shareCourseDetails() {
        String courseName = courseNameEditText.getText().toString();
        String courseStart = courseStartEditText.getText().toString();
        String courseEnd = courseEndEditText.getText().toString();
        String courseNotes = courseNoteEditText.getText().toString();

        String textToShare = "Course: " + courseName + "\n" +
                "Start Date: " + courseStart + "\n" +
                "End Date: " + courseEnd + "\n" +
                "Notes: " + courseNotes;

        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, textToShare);

        startActivity(Intent.createChooser(shareIntent, "Share Course Details"));
    }

    private void setAlertForStartDate() {
        // Retrieve the start date from the view
        String startDateFromScreen = courseStartEditText.getText().toString();

        // Parse the start date string to obtain a Date object
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy", Locale.US);
        Date startDate = null;
        try {
            startDate = sdf.parse(startDateFromScreen);
        } catch (ParseException | java.text.ParseException e) {
            e.printStackTrace();
        }

        if (startDate != null) {
            // Set up the alarm for the start date
            long triggerTime = startDate.getTime();

            // Create the intent for the alarm receiver
            Intent startIntent = new Intent(this, MyReceiver.class);
            startIntent.putExtra("key", startDateFromScreen + " this should trigger for start");
            PendingIntent startSender = PendingIntent.getBroadcast(
                    this,
                    0, // Use a unique request code if you have multiple alarms
                    startIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            // Get the AlarmManager and set the alarm
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (alarmManager != null) {
                // Use RTC_WAKEUP to trigger the alarm even when the device is in sleep mode
                alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, startSender);
                Toast.makeText(this, "Course Start Alert successfully set for: " + startDateFromScreen, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void setAlertForEndDate() {
        // Retrieve the end date from the view
        String endDateFromScreen = courseEndEditText.getText().toString();

        // Parse the end date string to obtain a Date object
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy", Locale.US);
        Date endDate = null;
        try {
            endDate = sdf.parse(endDateFromScreen);
        } catch (ParseException | java.text.ParseException e) {
            e.printStackTrace();
        }

        if (endDate != null) {
            // Set up the alarm for the end date
            long triggerTime = endDate.getTime();

            // Create the intent for the alarm receiver
            Intent endIntent = new Intent(this, MyReceiver.class);
            endIntent.putExtra("key", endDateFromScreen + " this should trigger for end");
            PendingIntent endSender = PendingIntent.getBroadcast(
                    this,
                    0, // Use a unique request code if you have multiple alarms
                    endIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            // Get the AlarmManager and set the alarm
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (alarmManager != null) {
                // Use RTC_WAKEUP to trigger the alarm even when the device is in sleep mode
                alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, endSender);
                Toast.makeText(this, "Course End Alert successfully set for: " + endDateFromScreen, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void navigateToAddAssessment() {
        Intent intent = new Intent(CourseDetail.this, AssessmentList.class);
        startActivity(intent);
    }



    private void saveChanges() {
        // Retrieve the course ID from the intent
        int courseID = getIntent().getIntExtra("courseID", -1);

        if (courseID != -1) {
            // Fetch the course from the repository or database using the courseID
            Course course = mRepository.getCourseByID(courseID);
            if (course != null) {
                // Update the course details
                course.setCourseName(courseNameEditText.getText().toString());
                course.setCourseStart(courseStartEditText.getText().toString());
                course.setCourseEnd(courseEndEditText.getText().toString());
                course.setCourseNote(courseNoteEditText.getText().toString());
                course.setProfessorName(professorNameEditText.getText().toString());
                course.setProfessorEmail(professorEmailEditText.getText().toString());
                course.setProfessorPhone(professorPhoneEditText.getText().toString());
                course.setCourseProgress(courseProgressSpinner.getSelectedItem().toString());

                // Get the selected term name from the spinner
                String selectedTermName = termIDSpinner.getSelectedItem().toString();
                if (selectedTermName != null) {
                    // Get the term ID based on the selected term name
                    int termID = mRepository.getTermIDByName(selectedTermName);
                    course.setTermID(termID);
                }

                // Update the course in the repository or database
                mRepository.updateCourse(course);

                finish();
            }
        }
    }

    private List<String> getTermNames(List<Term> termList) {
        List<String> termNames = new ArrayList<>();
        for (Term term : termList) {
            termNames.add(term.getTermName());
        }
        return termNames;
    }

    private int getTermPosition(int termID, List<Term> termList) {
        for (int i = 0; i < termList.size(); i++) {
            Term term = termList.get(i);
            if (term != null && term.getTermID() == termID) {
                return i;
            }
        }
        return 0;
    }

    @Override
    public void onItemClick(Assessment assessment) {
        // Handle assessment item click
        // Navigate to the AssessmentDetail activity passing the assessment ID
        Intent intent = new Intent(this, AssessmentDetail.class);
        intent.putExtra("assessmentID", assessment.getAssessmentID());
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Fetch the assessments associated with the course from the repository or database
        List<Assessment> assessments = mRepository.getAssessmentsByCourseID(courseID);
        assessmentAdapter.setAssessments(assessments);
    }


}
