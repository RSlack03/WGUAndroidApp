package android.reserver.myapplication.Database;

import android.app.Application;
import android.reserver.myapplication.DAO.AssessmentDAO;
import android.reserver.myapplication.DAO.CourseDAO;
import android.reserver.myapplication.DAO.TermDAO;
import android.reserver.myapplication.Entity.Assessment;
import android.reserver.myapplication.Entity.Course;
import android.reserver.myapplication.Entity.Term;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Repository {
    private AssessmentDAO mAssessmentDAO;
    private CourseDAO mCourseDAO;
    private TermDAO mTermDAO;

    private List<Assessment> mAllAssessments;
    private List<Course> mAllCourses;
    private List<Term> mAllTerms;


    private static int NUMBER_OF_THREADS=8;
    static final ExecutorService databaseExecutor= Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public Repository(Application application){
        SchoolDatabaseBuilder db=SchoolDatabaseBuilder.getDatabase(application);
        mAssessmentDAO= db.assessmentDAO();
        mCourseDAO= db.courseDAO();
        mTermDAO= db.termDAO();
    }



    //__________TERMS_____________//
    public List<Term> getmAllTerms(){
        databaseExecutor.execute(()->{
            mAllTerms=mTermDAO.getAllTerms();
        });
        try{
            Thread.sleep(1000);
        } catch (InterruptedException e){
            e.printStackTrace();
        }
        return mAllTerms;
    }

    public void insertTerm(Term term) {
        databaseExecutor.execute(() -> {
            mTermDAO.insert(term);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void updateTerm(Term term) {
        databaseExecutor.execute(() -> {
            mTermDAO.update(term);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void deleteTerm(Term term) {
        databaseExecutor.execute(() -> {
            mTermDAO.delete(term);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public Term getTermByID(int termID) {
        return mTermDAO.getTermByID(termID);
    }

    public int getTermIDByName(String termName) {
        return mTermDAO.getTermIDByName(termName);
    }



    //___________Course___________//
    public List<Course> getmAllCourses(){
        databaseExecutor.execute(()->{
            mAllCourses=mCourseDAO.getAllCourses();
        });
        try{
            Thread.sleep(1000);
        } catch (InterruptedException e){
            e.printStackTrace();
        }
        return mAllCourses;
    }

    public void insertCourse(Course course) {
        databaseExecutor.execute(()->{
         mCourseDAO.insert(course);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void updateCourse(Course course) {
        databaseExecutor.execute(() -> {
            mCourseDAO.update(course);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void deleteCourse(Course course) {
        databaseExecutor.execute(() -> {
            mCourseDAO.delete(course);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public Course getCourseByID(int courseID) {
        return mCourseDAO.getCourseByID(courseID);
    }

    public List<Course> getCoursesByTermID(int termID) {
        return mCourseDAO.getCoursesByTermID(termID);
    }


    //____________Assessment___________//

    public List<Assessment> getmAllAssessments() {
        databaseExecutor.execute(() -> {
            mAllAssessments = mAssessmentDAO.getAllAssessment();
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return mAllAssessments;
    }

    public void insertAssessment(Assessment assessment) {
        databaseExecutor.execute(() -> {
            mAssessmentDAO.insert(assessment);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void updateAssessment(Assessment assessment) {
        databaseExecutor.execute(() -> {
            mAssessmentDAO.update(assessment);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void deleteAssessment(Assessment assessment) {
        databaseExecutor.execute(() -> {
            mAssessmentDAO.delete(assessment);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public Assessment getAssessmentByID(int assessmentID) {
        return mAssessmentDAO.getAssessmentByID(assessmentID);
    }

    public List<Assessment> getAssessmentsByCourseID(int courseID) {
        return mAssessmentDAO.getAssessmentsByCourseID(courseID);
    }
}

