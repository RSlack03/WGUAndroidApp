package android.reserver.myapplication.UI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.reserver.myapplication.Database.Repository;
import android.reserver.myapplication.Entity.Course;
import android.reserver.myapplication.Entity.Term;
import android.reserver.myapplication.R;
import android.reserver.myapplication.UI.CourseAdapter;
import android.reserver.myapplication.UI.TermList;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TermDetail extends AppCompatActivity {

    private EditText editTermName;
    private EditText editTermStart;
    private EditText editTermEnd;
    DatePickerDialog.OnDateSetListener startDate;
    DatePickerDialog.OnDateSetListener endDate;
    final Calendar myCalendarStart = Calendar.getInstance();
    final Calendar myCalendarEnd = Calendar.getInstance();


    private Button buttonSaveChanges;
    private RecyclerView recyclerViewCourses;
    private CourseAdapter courseAdapter;

    private Repository mRepository;
    private Term term;
    private List<Course> filteredCourses;
    private int selectedTermID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms_detail);

        Intent intent = getIntent();
        selectedTermID = intent.getIntExtra("termID", -1); // Get the termID

        editTermName = findViewById(R.id.editTermName);
        editTermStart = findViewById(R.id.editTermStart);
        editTermEnd = findViewById(R.id.editTermEnd);
        buttonSaveChanges = findViewById(R.id.buttonSaveChanges);
        recyclerViewCourses = findViewById(R.id.recyclerViewCourses);
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        editTermStart.setText(sdf.format(new Date()));
        editTermEnd.setText(sdf.format(new Date()));

        courseAdapter = new CourseAdapter(TermDetail.this);
        recyclerViewCourses.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewCourses.setAdapter(courseAdapter);

        mRepository = new Repository(getApplication());

        // Fetch the complete Term object using the termID
        term = mRepository.getTermByID(selectedTermID);
        if (term != null) {
            // Set the term details in the EditText fields
            editTermName.setText(term.getTermName());
            editTermStart.setText(term.getTermStart());
            editTermEnd.setText(term.getTermEnd());
        }

        loadCourses();

        buttonSaveChanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveChanges();
            }
        });
        editTermStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Date date;
                String info=editTermStart.getText().toString();
                if(info.equals(""))info="02/10/22";
                try{
                    myCalendarStart.setTime(sdf.parse(info));
                } catch (ParseException e){
                    e.printStackTrace();
                }
                new DatePickerDialog(TermDetail.this, startDate, myCalendarStart
                        .get(Calendar.YEAR), myCalendarStart.get(Calendar.MONTH),
                        myCalendarStart.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        startDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendarStart.set(Calendar.YEAR, year);
                myCalendarStart.set(Calendar.MONTH, monthOfYear);
                myCalendarStart.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                updateLabelStart();

            }
        };
        editTermEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Date picker code for editTermEnd
                Date date;
                String info = editTermEnd.getText().toString();
                if (info.equals("")) info = "02/10/22";
                try {
                    myCalendarEnd.setTime(sdf.parse(info));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                new DatePickerDialog(TermDetail.this, endDate, myCalendarEnd
                        .get(Calendar.YEAR), myCalendarEnd.get(Calendar.MONTH),
                        myCalendarEnd.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        endDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendarEnd.set(Calendar.YEAR, year);
                myCalendarEnd.set(Calendar.MONTH, monthOfYear);
                myCalendarEnd.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                updateLabelEnd();
            }
        };
    }
    private void updateLabelStart() {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        editTermStart.setText(sdf.format(myCalendarStart.getTime()));
    }
    private void updateLabelEnd() {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        editTermEnd.setText(sdf.format(myCalendarEnd.getTime()));
    }


    private void loadCourses() {
        // Retrieve the courses with the matching term ID from the repository
        List<Course> filteredCourses = mRepository.getCoursesByTermID(selectedTermID);

        // Set the filtered courses in the adapter
        courseAdapter.setCourses(filteredCourses);

        // Set click listener for course item click
        courseAdapter.setOnItemClickListener(new CourseAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Course course) {
                // Handle course item click
                navigateToCourseDetail(course);
            }
        });
    }

    private void navigateToCourseDetail(Course course) {
        Intent intent = new Intent(TermDetail.this, CourseDetail.class);
        intent.putExtra("courseID", course.getCourseID());
        startActivity(intent);
    }

    private void saveChanges() {
        String termName = editTermName.getText().toString();
        String startDate = editTermStart.getText().toString();
        String endDate = editTermEnd.getText().toString();

        term.setTermName(termName);
        term.setTermStart(startDate);
        term.setTermEnd(endDate);

        mRepository.updateTerm(term);

        // TODO: Add any additional logic or UI updates after saving changes

        Intent intent = new Intent(TermDetail.this, TermList.class);
        finish();
    }
}

